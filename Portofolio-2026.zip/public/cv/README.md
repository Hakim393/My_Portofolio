# Curriculum Vitae Directory

Place your CV PDF file here with the filename:
`Fikhi_Hakim_CV.pdf`

The download button in the navigation and hero section links directly to:
`/cv/Fikhi_Hakim_CV.pdf`
