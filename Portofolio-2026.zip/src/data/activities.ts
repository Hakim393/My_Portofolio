import { Activity } from '../types';

export const activities: Activity[] = [
  {
    slug: 'campus-hiring',
    title: {
      en: 'Campus Hiring: "The Key to Build a Better User Experience"',
      id: 'Campus Hiring: "The Key to Build a Better User Experience"',
    },
    date: '2024',
    category: 'Event Experience',
    role: {
      en: 'Head of Event Division (Ketua Divisi Acara)',
      id: 'Ketua Divisi Acara',
    },
    organization: {
      en: 'HIMTI Universitas Gunadarma (Informatics Student Association)',
      id: 'HIMTI Universitas Gunadarma',
    },
    summary: {
      en: 'Led the event planning, rundown orchestration, and speaker coordination for HIMTI Gunadarma’s flagship campus hiring initiative, bridging undergraduate tech talent with industry software enterprises.',
      id: 'Memimpin perencanaan acara, perancangan rundown, dan koordinasi pembicara untuk agenda tahunan Campus Hiring HIMTI Universitas Gunadarma yang menghubungkan mahasiswa teknologi dengan industri.',
    },
    story: {
      en: [
        'Campus Hiring: "The Key to Build a Better User Experience" was organized by HIMTI Universitas Gunadarma as a premier bridge between students, recent graduates, and leading software organizations. The event centered on modern digital product creation, engineering workflows, and how user-centered design directly shapes backend and frontend architectures.',
        'As the Head of Event Division (Ketua Divisi Acara), I had the privilege and responsibility of shaping the overall participant journey from the initial keynote conception to the final recruitment interview sessions. This involved coordinating across multiple committee divisions—including logistics, public relations, technical crew, and creative design—ensuring an unbroken, punctual, and high-impact experience for over 200 attendee students and corporate partners.',
        'Through rigorous rehearsal, scenario-planning, and constant cross-functional communication, the event ran smoothly without technical interruptions, receiving overwhelmingly positive feedback from both attending industry speakers and student participants.',
      ],
      id: [
        'Campus Hiring: "The Key to Build a Better User Experience" diselenggarakan oleh HIMTI Universitas Gunadarma sebagai wadah strategis bagi mahasiswa dan lulusan baru untuk berinteraksi langsung dengan pimpinan industri teknologi. Acara ini membedah proses pengembangan produk digital, standar rekayasa perangkat lunak, serta integrasi pendekatan user-centric dalam arsitektur sistem.',
        'Sebagai Ketua Divisi Acara, saya memimpin perumusan konsep acara dari awal hingga pelaksanaan sesi interview rekrutmen. Tanggung jawab ini mencakup penyusunan rundown kegiatan secara terperinci, penyelarasan alur koordinasi antar divisi (logistik, hubungan masyarakat, multimedia, dan perlengkapan), serta memandu briefing pembicara industri.',
        'Melalui persiapan matang, simulasi teknis, dan komunikasi tim yang intensif, seluruh rangkaian acara terlaksana tepat waktu tanpa kendala berarti, serta menuai apresiasi tinggi dari para pembicara tamu maupun ratusan peserta mahasiswa.',
      ],
    },
    responsibilities: {
      en: [
        'Formulated and managed the minute-by-minute master event rundown for the entire multi-session program',
        'Coordinated speaker briefings, keynote alignment, and interactive Q&A discussion moderation',
        'Led a team of division members, delegating stage management, cue coordination, and timekeeping duties',
        'Liaised with partner company representatives to facilitate on-site booth workflows and career counseling sessions',
        'Conducted crisis-prevention simulations to handle potential technical and schedule contingencies',
      ],
      id: [
        'Merumuskan dan mengontrol master rundown acara secara terperinci untuk seluruh rangkaian sesi',
        'Mengkoordinasikan briefing materi dan kesiapan para pembicara industri sebelum sesi keynote dimulai',
        'Memimpin anggota divisi acara dalam pembagian tugas stage manager, operator cue, dan timekeeper',
        'Berkoordinasi dengan perwakilan mitra perusahaan untuk kelancaran alur sesi rekrutmen dan konsultasi karier',
        'Menyusun rencana kontingensi guna memitigasi potensi kendala teknis dan dinamika jadwal di lapangan',
      ],
    },
    takeaways: {
      en: [
        'Refined high-pressure decision making and leadership skills across multi-divisional committees',
        'Gained deep understanding of industry expectations regarding modern frontend and backend software practices',
        'Enhanced communication clarity when collaborating with corporate executives and university authorities',
      ],
      id: [
        'Mengasah kemampuan kepemimpinan dan pengambilan keputusan cepat di bawah situasi dengan intensitas tinggi',
        'Memperoleh wawasan mendalam mengenai ekspektasi riil industri terhadap kompetensi software engineer',
        'Meningkatkan keterampilan komunikasi profesional saat berkoordinasi dengan praktisi industri dan pihak kampus',
      ],
    },
    coverImage: '/images/activities/campus-hiring-cover.svg',
    gallery: [
      {
        src: '/images/activities/campus-hiring-1.svg',
        alt: {
          en: 'Event division committee conducting pre-event briefing',
          id: 'Divisi acara melakukan briefing persiapan teknis sebelum acara',
        },
        caption: {
          en: 'Coordination and rundown synchronization with stage and technical crews.',
          id: 'Sinkronisasi rundown dan koordinasi bersama kru teknis panggung.',
        },
      },
      {
        src: '/images/activities/campus-hiring-2.svg',
        alt: {
          en: 'Speaker presentation on User Experience and Software Architecture',
          id: 'Sesi presentasi pembicara mengenai User Experience dan Arsitektur Software',
        },
        caption: {
          en: 'Keynote presentation exploring user-centric engineering in production applications.',
          id: 'Sesi keynote mengulas penerapan standar rekayasa perangkat lunak berorientasi pengguna.',
        },
      },
      {
        src: '/images/activities/campus-hiring-3.svg',
        alt: {
          en: 'Closing group documentation with committee members',
          id: 'Dokumentasi penutupan bersama seluruh panitia penyelenggara',
        },
        caption: {
          en: 'Commemorating the successful execution of Campus Hiring with the HIMTI committee.',
          id: 'Dokumentasi bersama panitia HIMTI setelah sukses menyelenggarakan Campus Hiring.',
        },
      },
    ],
    tags: ['Leadership', 'Event Management', 'HIMTI Gunadarma', 'Campus Hiring', 'UX & Tech'],
    featured: true,
  },
  {
    slug: 'backend-architecture-workshop',
    title: {
      en: 'Technical Workshop: RESTful API & Relational Database Design',
      id: 'Workshop Teknis: Perancangan RESTful API & Database Relasional',
    },
    date: '2024',
    category: 'Organization',
    role: {
      en: 'Technical Participant & Facilitator Support',
      id: 'Peserta Aktif & Fasilitator Pendukung',
    },
    organization: {
      en: 'Informatics Study Community — Universitas Gunadarma',
      id: 'Komunitas Studi Informatika — Universitas Gunadarma',
    },
    summary: {
      en: 'Participated in and supported peer hands-on labs exploring Express.js middleware pipelines, schema normalizations in PostgreSQL, and API documentation with Swagger.',
      id: 'Mengikuti dan mendampingi sesi praktikum rekan mahasiswa mengenai pipeline middleware Express.js, normalisasi skema PostgreSQL, dan dokumentasi API dengan Swagger.',
    },
    story: {
      en: [
        'To strengthen technical foundations in backend development, I actively engaged in specialized community study workshops organized within the Informatics Engineering student circle. The sessions focused on the transition from basic scripting to architecting production-grade server services.',
        'During the sessions, we analyzed real-world scenarios including handling race conditions in inventory updates, designing idempotent payment hooks, and implementing structured logging for error traceability.',
      ],
      id: [
        'Guna memperkuat pondasi teknis di ranah rekayasa backend, saya berpartisipasi aktif dalam sesi workshop komunitas studi mahasiswa Teknik Informatika. Workshop ini berfokus pada transisi dari penulisan skrip dasar ke perancangan arsitektur server berstandar industri.',
        'Dalam sesi tersebut, kami membedah skenario praktis seperti mitigasi race condition pada pembaruan stok, pembuatan endpoint yang idempoten, serta penerapan logging terstruktur untuk kemudahan pelacakan error.',
      ],
    },
    responsibilities: {
      en: [
        'Built practice CRUD services with parameterized SQL queries and JWT route protection',
        'Collaborated on database ERD normalizations up to 3NF for e-commerce data entities',
        'Documented endpoints following OpenAPI 3.0 standards for teammate integration',
      ],
      id: [
        'Mengembangkan modul latihan CRUD dengan query SQL berparameter dan proteksi rute JWT',
        'Berkolaborasi dalam normalisasi diagram relasi entitas (ERD) hingga bentuk normal ketiga (3NF)',
        'Menyusun dokumentasi endpoint berstandar OpenAPI 3.0 untuk mempermudah integrasi tim',
      ],
    },
    takeaways: {
      en: [
        'Deepened practical mastery over asynchronous JavaScript and Express middleware chains',
        'Reinforced the importance of database indexing for query performance',
      ],
      id: [
        'Memperdalam penguasaan implementasi asynchronous JavaScript dan middleware Express',
        'Memahami signifikansi penggunaan indeks database dalam mengoptimalkan kecepatan query',
      ],
    },
    coverImage: '/images/activities/tech-workshop-cover.svg',
    tags: ['Backend', 'PostgreSQL', 'Express.js', 'REST API', 'Workshop'],
    featured: true,
  },
  {
    slug: 'sales-admin-ecommerce-operations',
    title: {
      en: 'Marketplace Operations & Customer Care — PT Indo Pro Teknologi',
      id: 'Operasional Marketplace & Pelayanan Pelanggan — PT Indo Pro Teknologi',
    },
    date: '2023 - 2024',
    category: 'Work Experience',
    role: {
      en: 'Sales Administrator',
      id: 'Sales Administrator',
    },
    organization: {
      en: 'PT Indo Pro Teknologi',
      id: 'PT Indo Pro Teknologi',
    },
    summary: {
      en: 'Managed end-to-end marketplace operations across Shopee and Tokopedia, ensuring accurate inventory records, invoice management, order dispatch, and customer resolution.',
      id: 'Mengelola operasional harian toko resmi di platform Shopee dan Tokopedia, meliputi pembaruan katalog, administrasi faktur, koordinasi gudang, dan penanganan komplain.',
    },
    story: {
      en: [
        'At PT Indo Pro Teknologi, I served as Sales Administrator handling business-critical operational workflows on major Indonesian e-commerce platforms (Tokopedia and Shopee). This role taught me the precision required to maintain operational synchronization between inventory stock in warehouses and active listings online.',
        'This experience directly informed my passion for backend software development—having managed high-volume e-commerce catalogs and order pipelines manually, I learned firsthand the exact bottlenecks and data consistency challenges that good software engineering must solve.',
      ],
      id: [
        'Di PT Indo Pro Teknologi, saya mengemban peran sebagai Sales Administrator yang menangani alur operasional toko resmi pada platform marketplace terkemuka di Indonesia (Tokopedia dan Shopee). Peran ini melatih ketelitian tinggi dalam menjaga akurasi data antara stok fisik di gudang dan etalase digital.',
        'Pengalaman ini berkontribusi langsung pada cara pandang saya dalam membangun sistem backend: setelah menyaksikan secara langsung alur pemrosesan pesanan dalam volume besar, saya memahami kendala riil dan tantangan integritas data yang wajib dijawab oleh rekayasa perangkat lunak yang andal.',
      ],
    },
    responsibilities: {
      en: [
        'Supervised product catalog listings, pricing matrices, and stock synchronization on Shopee and Tokopedia',
        'Processed customer orders, generated commercial invoices, and synchronized with warehouse dispatch crews',
        'Maintained structured reporting and data input for sales tracking and inventory reconciliation',
        'Addressed client inquiries and resolved after-sales customer complaints with professional etiquette',
      ],
      id: [
        'Mengelola etalase produk, penetapan harga, dan sinkronisasi ketersediaan stok di Shopee dan Tokopedia',
        'Memproses pesanan masuk, menerbitkan faktur penjualan, dan berkoordinasi dengan tim pengepakan gudang',
        'Menyusun laporan berkala dan entri data transaksi untuk rekonsiliasi berkala bagian logistik',
        'Melayani komunikasi pelanggan dan menyelesaikan keluhan pembeli secara cepat dan solutif',
      ],
    },
    takeaways: {
      en: [
        'Firsthand understanding of e-commerce business logic, status lifecycles, and logistical bottlenecks',
        'Exemplary attention to detail regarding data accuracy, invoices, and record keeping',
      ],
      id: [
        'Pemahaman mendalam mengenai siklus transaksi bisnis e-commerce dan dinamika logistik',
        'Ketelitian tinggi dalam administrasi data, pembuatan faktur, dan manajemen inventaris',
      ],
    },
    coverImage: '/images/projects/kstore-seapedia/cover.svg',
    tags: ['E-Commerce', 'Marketplace Management', 'Operations', 'Data Accuracy', 'Logistics'],
    featured: true,
  },
];
