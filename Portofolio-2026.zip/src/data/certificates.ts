import { CertificateItem } from '../types';

export const certificates: CertificateItem[] = [
  {
    id: 'dicoding-basic-web',
    title: {
      en: 'Belajar Dasar Pemrograman Web (Basic Web Programming)',
      id: 'Belajar Dasar Pemrograman Web',
    },
    issuer: 'Dicoding Indonesia',
    date: 'Certified',
    credentialId: 'YOUR_CREDENTIAL_ID',
    credentialUrl: 'YOUR_CERTIFICATE_URL',
    image: '/images/certificates/dicoding-web.svg',
    skillsCovered: ['HTML5', 'CSS3', 'Responsive Layouts', 'Flexbox', 'Web Fundamentals'],
    description: {
      en: 'Foundational certification covering semantic HTML tags, CSS styling techniques, accessible document structure, and responsive mobile layouts.',
      id: 'Sertifikasi kompetensi dasar yang mencakup sintaks semantik HTML, teknik styling CSS, struktur dokumen yang aksesibel, serta tata letak responsif.',
    },
  },
  {
    id: 'dicoding-frontend-pemula',
    title: {
      en: 'Belajar Membuat Front-End Web untuk Pemula (Frontend Web for Beginners)',
      id: 'Belajar Membuat Front-End Web untuk Pemula',
    },
    issuer: 'Dicoding Indonesia',
    date: 'Certified',
    credentialId: 'YOUR_CREDENTIAL_ID',
    credentialUrl: 'YOUR_CERTIFICATE_URL',
    image: '/images/certificates/dicoding-frontend.svg',
    skillsCovered: ['JavaScript DOM', 'Web Storage API', 'Event Handling', 'Client-Side Interactions'],
    description: {
      en: 'Intermediate frontend competency training focusing on interactive DOM manipulation, custom event listeners, browser localStorage state persistence, and modular JavaScript.',
      id: 'Pelatihan kompetensi frontend tingkat pemula yang membedah manipulasi DOM secara interaktif, event listener, penyimpanan data lokal browser (Web Storage), dan JavaScript modular.',
    },
  },
  {
    id: 'duniacoding-basic-nextjs',
    title: {
      en: 'Basic Next.js & Modern React Architecture',
      id: 'Dasar Next.js & Arsitektur React Modern',
    },
    issuer: 'Dunia Coding',
    date: 'Certified',
    credentialId: 'YOUR_CREDENTIAL_ID',
    credentialUrl: 'YOUR_CERTIFICATE_URL',
    image: '/images/certificates/duniacoding-nextjs.svg',
    skillsCovered: ['Next.js', 'React', 'Component Lifecycle', 'Routing', 'API Integration'],
    description: {
      en: 'Comprehensive workshop on Next.js file-system routing, server vs client rendering fundamentals, component lifecycle synchronization, and external API fetching.',
      id: 'Workshop komprehensif mengenai file-system routing pada Next.js, konsep dasar rendering sisi server dan klien, siklus hidup komponen, serta integrasi endpoint API.',
    },
  },
  {
    id: 'udemy-webdev-bootcamp',
    title: {
      en: 'The Complete Web Development Bootcamp',
      id: 'The Complete Web Development Bootcamp',
    },
    issuer: 'Udemy',
    date: 'Certified',
    credentialId: 'YOUR_CREDENTIAL_ID',
    credentialUrl: 'YOUR_CERTIFICATE_URL',
    image: '/images/certificates/udemy-webdev.svg',
    skillsCovered: ['Full-Stack Web', 'Node.js', 'Express.js', 'PostgreSQL / SQL', 'REST APIs'],
    description: {
      en: 'Intensive end-to-end full-stack curriculum spanning backend architecture with Node.js and Express, relational databases with SQL/PostgreSQL, authentication, and client development.',
      id: 'Kurikulum intensif full-stack web development yang mencakup arsitektur backend Node.js dan Express, pemodelan database relasional SQL/PostgreSQL, keamanan autentikasi, dan aplikasi klien.',
    },
  },
];
