import { ExperienceItem } from '../types';

export const experiences: ExperienceItem[] = [
  {
    id: 'pt-indo-pro-teknologi',
    role: {
      en: 'Sales Administrator',
      id: 'Sales Administrator',
    },
    company: {
      en: 'PT Indo Pro Teknologi',
      id: 'PT Indo Pro Teknologi',
    },
    type: {
      en: 'Work Experience',
      id: 'Pengalaman Kerja',
    },
    period: {
      en: 'Professional Experience',
      id: 'Pengalaman Profesional',
    },
    location: {
      en: 'Indonesia',
      id: 'Indonesia',
    },
    summary: {
      en: 'Managed end-to-end e-commerce store operations, data reporting, customer communications, and warehouse logistics coordination.',
      id: 'Mengelola operasional toko e-commerce terpadu, pelaporan data transaksi, komunikasi pelanggan, dan koordinasi logistik gudang.',
    },
    responsibilities: {
      en: [
        'Data input and structured commercial transaction reporting',
        'Customer inquiry follow-up and prompt communication service',
        'Marketplace store management across Shopee and Tokopedia',
        'Product management: creating new listings, catalog descriptions, and image updates',
        'Real-time price adjustment and warehouse stock synchronization',
        'Order processing and sales workflow verification',
        'Invoice generation and documentation handling',
        'Direct coordination with packing and warehouse logistics teams',
        'Handling customer complaints and resolving after-sales requests constructively',
      ],
      id: [
        'Entri data dan penyusunan pelaporan transaksi komersial berkala',
        'Follow-up komunikasi pelanggan dan penanganan pertanyaan pembeli secara responsif',
        'Manajemen operasional etalase marketplace (Shopee dan Tokopedia)',
        'Pengelolaan produk: unggah produk baru, perbaikan deskripsi, dan pembaruan visual',
        'Pembaruan harga berkala serta sinkronisasi ketersediaan stok fisik gudang',
        'Pemrosesan pesanan harian dan validasi alur pembayaran transaksi',
        'Penerbitan faktur (invoice) serta pengarsipan dokumen penjualan',
        'Koordinasi langsung dengan tim operasional gudang dan bagian pengemasan',
        'Penanganan keluhan pelanggan serta penyelesaian kendala pascajual secara solutif',
      ],
    },
    badge: {
      en: 'Marketplace & Operations',
      id: 'Marketplace & Operasional',
    },
  },
  {
    id: 'himti-gunadarma-event-division',
    role: {
      en: 'Head of Event Division (Ketua Divisi Acara)',
      id: 'Ketua Divisi Acara',
    },
    company: {
      en: 'HIMTI Universitas Gunadarma',
      id: 'HIMTI Universitas Gunadarma',
    },
    type: {
      en: 'Organizational Leadership',
      id: 'Organisasi Mahasiswa',
    },
    period: {
      en: 'Academic Term',
      id: 'Periode Kepengurusan',
    },
    location: {
      en: 'Universitas Gunadarma, Depok',
      id: 'Universitas Gunadarma, Depok',
    },
    summary: {
      en: 'Spearheaded event architecture and operational timeline for Campus Hiring ("The Key to Build a Better User Experience"), orchestrating student-industry connection programs.',
      id: 'Memimpin perencanaan alur acara dan timeline operasional Campus Hiring bertajuk "The Key to Build a Better User Experience" yang mempertemukan mahasiswa dengan praktisi industri.',
    },
    responsibilities: {
      en: [
        'Authored and controlled master rundowns for multi-session seminars and recruiter meetups',
        'Briefed keynote speakers and synchronized event agendas with university leadership',
        'Delegated and supervised duties for stage management, technical operators, and hosts',
        'Maintained rapid communication across logistic, documentation, and PR teams to resolve operational hurdles',
      ],
      id: [
        'Menyusun dan mengontrol master rundown acara seminar dan rekrutmen kampus',
        'Melakukan briefing pembicara industri serta menyelaraskan agenda dengan pihak kampus',
        'Mendelegasikan dan mengawasi tugas kru panggung, operator teknis, dan MC',
        'Menjaga koordinasi cepat antar divisi logistik, dokumentasi, dan humas demi kelancaran kegiatan',
      ],
    },
    badge: {
      en: 'Leadership & Coordination',
      id: 'Kepemimpinan & Koordinasi',
    },
  },
  {
    id: 'gunadarma-informatics-engineering',
    role: {
      en: 'Informatics Engineering Student',
      id: 'Mahasiswa Teknik Informatika',
    },
    company: {
      en: 'Universitas Gunadarma',
      id: 'Universitas Gunadarma',
    },
    type: {
      en: 'Higher Education & Applied Tech',
      id: 'Pendidikan Tinggi & Praktik Teknologi',
    },
    period: {
      en: 'Undergraduate',
      id: 'Program Sarjana',
    },
    location: {
      en: 'Depok, West Java',
      id: 'Depok, Jawa Barat',
    },
    summary: {
      en: 'Focusing on backend software engineering, relational database design, algorithm design, and modern web application development.',
      id: 'Fokus mendalami rekayasa perangkat lunak backend, perancangan basis data relasional, struktur data dan algoritma, serta pengembangan aplikasi web modern.',
    },
    responsibilities: {
      en: [
        'Studied software lifecycle, data structures, object-oriented programming, and discrete math',
        'Implemented academic and laboratory projects exploring SQL modeling and REST services',
        'Collaborated with fellow students on technical research and web-based implementations',
      ],
      id: [
        'Mempelajari siklus pengembangan perangkat lunak, struktur data, pemrograman berorientasi objek, dan basis data',
        'Mengimplementasikan proyek praktikum yang berfokus pada pemodelan SQL dan layanan REST API',
        'Berkolaborasi dalam riset teknis kelompok dan implementasi prototipe berbasis web',
      ],
    },
    badge: {
      en: 'Academic Focus',
      id: 'Fokus Akademik',
    },
  },
];
